"use strict";

const STORAGE_KEY = "stillpoint-writing-studio-v1";
const DEFAULT_MINUTES = 15;
const MAX_SAFE_MINUTES = Math.floor(Number.MAX_SAFE_INTEGER / 60_000);

const elements = {
  completionExportButton: document.querySelector("#completionExportButton"),
  completionPanel: document.querySelector("#completionPanel"),
  completionResetButton: document.querySelector("#completionResetButton"),
  content: document.querySelector("#postContent"),
  customDuration: document.querySelector("#customDuration"),
  customDurationWrap: document.querySelector("#customDurationWrap"),
  deleteDraftButton: document.querySelector("#deleteDraftButton"),
  draftCount: document.querySelector("#draftCount"),
  draftList: document.querySelector("#draftList"),
  durationSelect: document.querySelector("#durationSelect"),
  editorLabel: document.querySelector("#editorLabel"),
  exportButton: document.querySelector("#exportButton"),
  focusMessage: document.querySelector("#focusMessage"),
  newDraftButton: document.querySelector("#newDraftButton"),
  notice: document.querySelector("#notice"),
  pauseButton: document.querySelector("#pauseButton"),
  postTitle: document.querySelector("#postTitle"),
  resetButton: document.querySelector("#resetButton"),
  saveStatus: document.querySelector("#saveStatus"),
  startButton: document.querySelector("#startButton"),
  themeToggle: document.querySelector("#themeToggle"),
  timer: document.querySelector("#timer"),
  timerCaption: document.querySelector("#timerCaption"),
  wordCount: document.querySelector("#wordCount"),
};

function createDraft() {
  const timestamp = Date.now();
  return {
    id: globalThis.crypto?.randomUUID?.() ?? `draft-${timestamp}-${Math.random().toString(36).slice(2)}`,
    title: "",
    content: "",
    updatedAt: timestamp,
  };
}

function createInitialState() {
  const draft = createDraft();
  return {
    version: 1,
    drafts: [draft],
    selectedDraftId: draft.id,
    theme: "light",
    session: {
      status: "idle",
      durationMs: DEFAULT_MINUTES * 60_000,
      remainingMs: DEFAULT_MINUTES * 60_000,
      endAt: null,
    },
  };
}

function isValidState(value) {
  return Boolean(
    value &&
    value.version === 1 &&
    Array.isArray(value.drafts) &&
    value.drafts.every((draft) =>
      draft &&
      typeof draft.id === "string" &&
      typeof draft.title === "string" &&
      typeof draft.content === "string"
    ) &&
    ["light", "dark"].includes(value.theme) &&
    value.session &&
    ["idle", "running", "paused", "complete"].includes(value.session.status)
  );
}

let storageWritable = true;

function loadState() {
  let serialized;
  try {
    serialized = localStorage.getItem(STORAGE_KEY);
  } catch (error) {
    storageWritable = false;
    console.error("Could not read the Stillpoint browser storage.", error);
    showNotice("Browser storage is unavailable. Drafts may not persist.");
    return createInitialState();
  }

  if (!serialized) {
    return createInitialState();
  }

  try {
    const saved = JSON.parse(serialized);
    if (!isValidState(saved)) {
      throw new Error("The saved data did not match the expected draft format.");
    }

    if (saved.drafts.length === 0) {
      const draft = createDraft();
      saved.drafts.push(draft);
      saved.selectedDraftId = draft.id;
    } else if (!saved.drafts.some((draft) => draft.id === saved.selectedDraftId)) {
      saved.selectedDraftId = saved.drafts[0].id;
    }

    const session = saved.session;
    if (!Number.isFinite(session.durationMs) || session.durationMs <= 0) {
      session.durationMs = DEFAULT_MINUTES * 60_000;
    }
    if (!Number.isFinite(session.remainingMs) || session.remainingMs < 0) {
      session.remainingMs = session.durationMs;
    }
    if (session.status === "running") {
      if (!Number.isFinite(session.endAt) || session.endAt <= Date.now()) {
        session.status = "complete";
        session.remainingMs = 0;
        session.endAt = null;
      } else {
        session.remainingMs = session.endAt - Date.now();
      }
    }
    if (session.status === "complete") {
      session.remainingMs = 0;
      session.endAt = null;
    }
    return saved;
  } catch (error) {
    storageWritable = false;
    console.error("Could not restore the saved Stillpoint drafts.", error);
    showNotice("Saved data could not be read. A new draft was opened; the stored data was left untouched.");
    return createInitialState();
  }
}

let state = loadState();
let noticeTimeout;
let timerInterval;

function showNotice(message) {
  elements.notice.textContent = message;
  elements.notice.hidden = false;
  window.clearTimeout(noticeTimeout);
  noticeTimeout = window.setTimeout(() => {
    elements.notice.hidden = true;
  }, 6000);
}

function persistState() {
  if (!storageWritable) {
    elements.saveStatus.textContent = "Could not save";
    return false;
  }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    elements.saveStatus.textContent = "Saved locally";
    return true;
  } catch (error) {
    storageWritable = false;
    console.error("Could not save the Stillpoint draft.", error);
    elements.saveStatus.textContent = "Could not save";
    showNotice("This draft could not be saved to browser storage. Export a copy to keep your work.");
    return false;
  }
}

function selectedDraft() {
  return state.drafts.find((draft) => draft.id === state.selectedDraftId);
}

function formatTime(milliseconds) {
  const seconds = Math.max(0, Math.ceil(milliseconds / 1000));
  const minutesPart = Math.floor(seconds / 60);
  const secondsPart = seconds % 60;
  return `${String(minutesPart).padStart(2, "0")}:${String(secondsPart).padStart(2, "0")}`;
}

function getChosenDuration() {
  const rawMinutes = elements.durationSelect.value === "custom"
    ? elements.customDuration.value.trim()
    : elements.durationSelect.value;
  const minutes = Number(rawMinutes);
  if (!Number.isSafeInteger(minutes) || minutes < 1 || minutes > MAX_SAFE_MINUTES) {
    showNotice(`Choose a whole number of minutes from 1 to ${MAX_SAFE_MINUTES}.`);
    elements.customDuration.focus();
    return null;
  }
  return minutes * 60_000;
}

function countWords(text) {
  const trimmed = text.trim();
  return trimmed ? trimmed.split(/\s+/u).length : 0;
}

function renderDraftList() {
  elements.draftList.replaceChildren();
  elements.draftCount.textContent = String(state.drafts.length);

  for (const draft of [...state.drafts].sort((a, b) => b.updatedAt - a.updatedAt)) {
    const item = document.createElement("li");
    item.className = "draft-item";

    const button = document.createElement("button");
    button.className = "draft-button";
    button.type = "button";
    button.textContent = draft.title.trim() || "Untitled draft";
    button.setAttribute("aria-current", String(draft.id === state.selectedDraftId));
    button.disabled = state.session.status === "complete";
    button.addEventListener("click", () => selectDraft(draft.id));

    item.append(button);
    elements.draftList.append(item);
  }

  elements.newDraftButton.disabled = state.session.status === "complete";
  elements.deleteDraftButton.disabled = state.session.status === "complete";
}

function renderEditor() {
  const draft = selectedDraft();
  if (!draft) {
    return;
  }

  elements.postTitle.value = draft.title;
  elements.content.value = draft.content;
  elements.editorLabel.textContent = draft.title.trim() || "A new beginning";
  elements.wordCount.textContent = `${countWords(draft.content)} ${countWords(draft.content) === 1 ? "word" : "words"}`;
  const locked = state.session.status === "complete";
  elements.postTitle.disabled = locked;
  elements.content.disabled = locked;
  elements.completionPanel.hidden = !locked;
  document.body.classList.toggle("session-completed", locked);
  renderDraftList();
}

function renderTimer() {
  const session = state.session;
  const isRunning = session.status === "running";
  const isPaused = session.status === "paused";
  const isComplete = session.status === "complete";
  let remaining = session.remainingMs;

  if (isRunning) {
    remaining = Math.max(0, session.endAt - Date.now());
  } else if (session.status === "idle") {
    const selected = elements.durationSelect.value === "custom"
      ? Number(elements.customDuration.value)
      : Number(elements.durationSelect.value);
    if (Number.isSafeInteger(selected) && selected > 0) {
      remaining = selected * 60_000;
    }
  }

  elements.timer.textContent = formatTime(remaining);
  elements.timer.setAttribute("aria-label", `${Math.ceil(remaining / 60_000)} minutes and ${Math.ceil((remaining % 60_000) / 1000)} seconds remaining`);
  elements.timerCaption.textContent = isRunning
    ? "Time to write"
    : isPaused
      ? "Session paused"
      : isComplete
        ? "Session finished"
        : "Ready when you are";

  elements.startButton.hidden = isRunning || isComplete;
  elements.startButton.textContent = isPaused ? "Resume" : "Start writing";
  elements.pauseButton.hidden = !isRunning;
  elements.resetButton.hidden = session.status === "idle";
  elements.resetButton.textContent = isComplete ? "Reset timer" : "Reset";

  const focusMode = isRunning || isPaused;
  document.body.classList.toggle("focus-mode", focusMode);
  elements.focusMessage.textContent = isPaused
    ? "Your timer is paused. Resume when you’re ready."
    : "Your session is underway. Stay with the words.";
}

function renderTheme() {
  const isDark = state.theme === "dark";
  document.documentElement.dataset.theme = state.theme;
  elements.themeToggle.setAttribute("aria-pressed", String(isDark));
  elements.themeToggle.setAttribute("aria-label", `Switch to ${isDark ? "light" : "dark"} theme`);
}

function render() {
  renderDraftList();
  renderEditor();
  renderTimer();
  renderTheme();
}

function updateDraftFromEditor() {
  const draft = selectedDraft();
  if (!draft || state.session.status === "complete") {
    return;
  }

  draft.title = elements.postTitle.value;
  draft.content = elements.content.value;
  draft.updatedAt = Date.now();
  elements.editorLabel.textContent = draft.title.trim() || "A new beginning";
  const words = countWords(draft.content);
  elements.wordCount.textContent = `${words} ${words === 1 ? "word" : "words"}`;
  persistState();
  renderDraftList();
}

function selectDraft(id) {
  if (state.session.status === "complete") {
    showNotice("Reset the completed session before opening another draft.");
    return;
  }
  if (!state.drafts.some((draft) => draft.id === id)) {
    showNotice("That draft could not be found.");
    return;
  }

  updateDraftFromEditor();
  state.selectedDraftId = id;
  renderEditor();
  persistState();
}

function addDraft() {
  if (state.session.status === "complete") {
    showNotice("Reset the completed session before starting another draft.");
    return;
  }
  updateDraftFromEditor();
  const draft = createDraft();
  state.drafts.push(draft);
  state.selectedDraftId = draft.id;
  renderEditor();
  elements.postTitle.focus();
  persistState();
}

function deleteSelectedDraft() {
  if (state.session.status === "complete") {
    showNotice("Reset the completed session before deleting a draft.");
    return;
  }
  const draft = selectedDraft();
  if (!draft) {
    return;
  }
  const name = draft.title.trim() || "this untitled draft";
  if (!window.confirm(`Delete ${name}? This cannot be undone.`)) {
    return;
  }

  state.drafts = state.drafts.filter((item) => item.id !== draft.id);
  if (state.drafts.length === 0) {
    state.drafts.push(createDraft());
  }
  state.selectedDraftId = state.drafts[0].id;
  renderEditor();
  persistState();
}

function startSession() {
  if (state.session.status === "complete") {
    return;
  }

  if (state.session.status === "paused") {
    state.session.endAt = Date.now() + state.session.remainingMs;
  } else {
    const durationMs = getChosenDuration();
    if (durationMs === null) {
      return;
    }
    state.session.durationMs = durationMs;
    state.session.remainingMs = durationMs;
    state.session.endAt = Date.now() + durationMs;
  }
  state.session.status = "running";
  renderTimer();
  persistState();
  elements.content.focus();
  if (!timerInterval) {
    timerInterval = window.setInterval(updateRunningTimer, 250);
  }
}

function pauseSession() {
  if (state.session.status !== "running") {
    return;
  }
  state.session.remainingMs = Math.max(0, state.session.endAt - Date.now());
  if (state.session.remainingMs === 0) {
    completeSession();
    return;
  }
  state.session.status = "paused";
  state.session.endAt = null;
  renderTimer();
  persistState();
}

function completeSession() {
  state.session.status = "complete";
  state.session.remainingMs = 0;
  state.session.endAt = null;
  window.clearInterval(timerInterval);
  timerInterval = null;
  render();
  persistState();
  showNotice("Time is up. Your draft is saved and editing is locked until you reset.");
  elements.completionExportButton.focus();
}

function resetSession() {
  window.clearInterval(timerInterval);
  timerInterval = null;
  const selected = getChosenDuration();
  const durationMs = selected ?? state.session.durationMs ?? DEFAULT_MINUTES * 60_000;
  state.session = {
    status: "idle",
    durationMs,
    remainingMs: durationMs,
    endAt: null,
  };
  render();
  persistState();
}

function updateRunningTimer() {
  if (state.session.status !== "running") {
    return;
  }
  state.session.remainingMs = Math.max(0, state.session.endAt - Date.now());
  if (state.session.remainingMs === 0) {
    completeSession();
    return;
  }
  renderTimer();
}

function exportMarkdown() {
  const draft = selectedDraft();
  if (!draft) {
    showNotice("There is no draft to export.");
    return;
  }

  const title = draft.title.trim() || "Untitled";
  const markdown = `# ${title}\n\n${draft.content.trim()}\n`;
  const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const filename = title
    .normalize("NFKD")
    .replace(/[^\w -]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .toLowerCase() || "untitled";

  link.href = url;
  link.download = `${filename}.md`;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function handleDurationChange() {
  const isCustom = elements.durationSelect.value === "custom";
  elements.customDurationWrap.hidden = !isCustom;
  if (state.session.status === "idle") {
    renderTimer();
  }
}

elements.postTitle.addEventListener("input", updateDraftFromEditor);
elements.content.addEventListener("input", updateDraftFromEditor);
elements.newDraftButton.addEventListener("click", addDraft);
elements.deleteDraftButton.addEventListener("click", deleteSelectedDraft);
elements.startButton.addEventListener("click", startSession);
elements.pauseButton.addEventListener("click", pauseSession);
elements.resetButton.addEventListener("click", resetSession);
elements.completionResetButton.addEventListener("click", resetSession);
elements.exportButton.addEventListener("click", exportMarkdown);
elements.completionExportButton.addEventListener("click", exportMarkdown);
elements.durationSelect.addEventListener("change", handleDurationChange);
elements.customDuration.addEventListener("input", () => {
  if (state.session.status === "idle") {
    renderTimer();
  }
});
elements.themeToggle.addEventListener("click", () => {
  state.theme = state.theme === "dark" ? "light" : "dark";
  renderTheme();
  persistState();
});

if (state.drafts.length === 0) {
  const draft = createDraft();
  state.drafts.push(draft);
  state.selectedDraftId = draft.id;
}

if (state.session.status === "running" && state.session.endAt <= Date.now()) {
  state.session.status = "complete";
  state.session.remainingMs = 0;
  state.session.endAt = null;
}

render();
persistState();

if (state.session.status === "running") {
  timerInterval = window.setInterval(updateRunningTimer, 250);
}
