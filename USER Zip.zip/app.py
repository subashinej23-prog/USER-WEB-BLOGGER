from datetime import datetime, timezone
import os
import re
from urllib.parse import urljoin, urlsplit

from flask import Flask, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-change-me')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blog.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

_db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'warning'

DOMAIN_PATTERN = re.compile(
    r'(?=.{1,253}\Z)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+'
    r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\Z',
    re.IGNORECASE,
)


class User(UserMixin, _db.Model):
    id = _db.Column(_db.Integer, primary_key=True)
    username = _db.Column(_db.String(80), unique=True, nullable=False)
    email = _db.Column(_db.String(120), unique=True, nullable=False)
    password_hash = _db.Column(_db.String(256), nullable=False)
    posts = _db.relationship('Post', backref='author', lazy=True)
    comments = _db.relationship('Comment', backref='author', lazy=True)
    blocked_websites = _db.relationship('BlockedWebsite', backref='owner', lazy=True,
                                        cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Post(_db.Model):
    id = _db.Column(_db.Integer, primary_key=True)
    title = _db.Column(_db.String(200), nullable=False)
    category = _db.Column(_db.String(50), nullable=False)
    content = _db.Column(_db.Text, nullable=False)
    image_url = _db.Column(_db.String(500))
    date_posted = _db.Column(_db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    user_id = _db.Column(_db.Integer, _db.ForeignKey('user.id'), nullable=False)
    comments = _db.relationship('Comment', backref='post', lazy=True,
                                cascade='all, delete-orphan', order_by='Comment.date_posted.desc()')


class Comment(_db.Model):
    id = _db.Column(_db.Integer, primary_key=True)
    content = _db.Column(_db.Text, nullable=False)
    date_posted = _db.Column(_db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    user_id = _db.Column(_db.Integer, _db.ForeignKey('user.id'), nullable=False)
    post_id = _db.Column(_db.Integer, _db.ForeignKey('post.id'), nullable=False)


class BlockedWebsite(_db.Model):
    id = _db.Column(_db.Integer, primary_key=True)
    website_name = _db.Column(_db.String(120), nullable=False)
    domain_url = _db.Column(_db.String(253), nullable=False)
    start_time = _db.Column(_db.Time, nullable=False)
    end_time = _db.Column(_db.Time, nullable=False)
    is_active = _db.Column(_db.Boolean, nullable=False, default=True)
    user_id = _db.Column(_db.Integer, _db.ForeignKey('user.id'), nullable=False)


@login_manager.user_loader
def load_user(user_id):
    return _db.session.get(User, int(user_id))


def is_safe_redirect_target(target):
    if not target or '\\' in target:
        return False
    destination = urlsplit(urljoin(request.host_url, target))
    origin = urlsplit(request.host_url)
    return destination.scheme in {'http', 'https'} and destination.netloc == origin.netloc


def parse_block_time(value):
    if not value or not re.fullmatch(r'\d{2}:\d{2}', value):
        return None
    try:
        return datetime.strptime(value, '%H:%M').time()
    except ValueError:
        return None


def normalize_domain(value):
    domain = (value or '').strip().lower().rstrip('.')
    if not DOMAIN_PATTERN.fullmatch(domain):
        return None
    return domain


def schedule_is_active(start_time, end_time, now):
    if start_time < end_time:
        return start_time <= now < end_time
    return now >= start_time or now < end_time


def get_active_blocker_details(user_id, now):
    blockers = BlockedWebsite.query.filter_by(user_id=user_id, is_active=True).all()
    return [
        {
            'blocker': blocker,
            'ends_tomorrow': blocker.start_time > blocker.end_time and now >= blocker.start_time,
        }
        for blocker in blockers
        if schedule_is_active(blocker.start_time, blocker.end_time, now)
    ]


def validate_blocker_form(form):
    website_name = form.get('website_name', '').strip()
    domain_url = normalize_domain(form.get('domain_url'))
    start_time = parse_block_time(form.get('start_time', ''))
    end_time = parse_block_time(form.get('end_time', ''))

    if not website_name or len(website_name) > 120:
        return None, 'Enter a website name between 1 and 120 characters.'
    if not domain_url:
        return None, 'Enter a valid domain, such as instagram.com, without a path or URL scheme.'
    if start_time is None or end_time is None:
        return None, 'Choose valid start and end times in 24-hour HH:MM format.'
    if start_time == end_time:
        return None, 'Start and end times must be different.'
    return {
        'website_name': website_name,
        'domain_url': domain_url,
        'start_time': start_time,
        'end_time': end_time,
    }, None


def blocker_dashboard_context(editing_blocker=None, form_values=None):
    now = datetime.now()
    blockers = BlockedWebsite.query.filter_by(user_id=current_user.id).order_by(
        BlockedWebsite.start_time.asc(),
        BlockedWebsite.website_name.asc(),
    ).all()
    blocker_rows = [
        {
            'blocker': blocker,
            'active_now': blocker.is_active and schedule_is_active(
                blocker.start_time, blocker.end_time, now.time()
            ),
        }
        for blocker in blockers
    ]
    return {
        'blockers': blocker_rows,
        'editing_blocker': editing_blocker,
        'form_values': form_values or {},
        'server_now_seconds': now.hour * 3600 + now.minute * 60 + now.second,
    }


with app.app_context():
    _db.create_all()
    if not User.query.first():
        alice = User(username='alice', email='alice@example.com')
        alice.set_password('password123')
        bob = User(username='bob', email='bob@example.com')
        bob.set_password('password123')
        _db.session.add_all([alice, bob])
        _db.session.flush()

        now = datetime.now(timezone.utc)
        posts = [
            Post(title='The Future of Everyday Technology', category='Tech',
                 content='Technology is becoming less visible and more useful. From ambient devices to thoughtful AI assistants, the best innovations quietly remove friction from daily life.\n\nThis shift is not just about faster processors or smarter software. It is about designing products that respect attention, privacy, and the human need for simple, dependable experiences.',
                 image_url='https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
                 date_posted=now, user_id=alice.id),
            Post(title='Finding Stillness in a Busy City', category='Lifestyle',
                 content='A slower life does not require moving far away. It can begin with a morning walk without a phone, a familiar café, or a few quiet minutes beside an open window.\n\nWhen we create small rituals, ordinary spaces become places of renewal. The city keeps moving, but we do not have to move at its pace.',
                 image_url='https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1200&q=80',
                 date_posted=datetime.now(timezone.utc), user_id=bob.id),
            Post(title='Notes from the Northern Coast', category='Travel',
                 content='The road north followed the sea, curving past fishing villages and weathered cliffs. Every stop offered another lesson in distance: a lighthouse disappearing into fog, gulls circling an empty harbor, and light shifting across the water.\n\nTravel is often remembered through details rather than destinations. Here, the details were salt, wind, and the warm hospitality of people who call this rugged coast home.',
                 image_url='https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                 date_posted=datetime.now(timezone.utc), user_id=alice.id)
        ]
        _db.session.add_all(posts)
        _db.session.commit()


@app.route('/')
def index():
    query = request.args.get('q', '').strip()
    category = request.args.get('category', 'All')
    posts = Post.query
    if query:
        search = f'%{query}%'
        posts = posts.filter(_db.or_(Post.title.ilike(search), Post.content.ilike(search)))
    if category in {'Tech', 'Lifestyle', 'Travel'}:
        posts = posts.filter_by(category=category)
    posts = posts.order_by(Post.date_posted.desc()).all()
    return render_template('index.html', posts=posts, category=category, query=query)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        if not username or not email or not password:
            flash('All fields are required.', 'danger')
        elif User.query.filter_by(username=username).first():
            flash('That username is already taken.', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('That email is already registered.', 'danger')
        else:
            user = User(username=username, email=email)
            user.set_password(password)
            _db.session.add(user)
            _db.session.commit()
            login_user(user)
            flash('Welcome! Your account has been created.', 'success')
            return redirect(url_for('index'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully.', 'success')
            next_url = request.args.get('next')
            if is_safe_redirect_target(next_url):
                return redirect(next_url)
            return redirect(url_for('index'))
        flash('Invalid username or password.', 'danger')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))


@app.route('/blocker', methods=['GET', 'POST'])
@login_required
def blocker_dashboard():
    if request.method == 'POST':
        values, error = validate_blocker_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template(
                'blocker.html',
                **blocker_dashboard_context(form_values=request.form.to_dict()),
            )
        else:
            blocker = BlockedWebsite(
                **values,
                user_id=current_user.id,
            )
            _db.session.add(blocker)
            _db.session.commit()
            flash('Website schedule saved.', 'success')
            return redirect(url_for('blocker_dashboard'))

    return render_template('blocker.html', **blocker_dashboard_context())


@app.route('/blocker/<int:blocker_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_blocker(blocker_id):
    blocker = BlockedWebsite.query.filter_by(
        id=blocker_id,
        user_id=current_user.id,
    ).first_or_404()

    if request.method == 'POST':
        values, error = validate_blocker_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template(
                'blocker.html',
                **blocker_dashboard_context(
                    editing_blocker=blocker,
                    form_values=request.form.to_dict(),
                ),
            )
        for field, value in values.items():
            setattr(blocker, field, value)
        _db.session.commit()
        flash('Website schedule updated.', 'success')
        return redirect(url_for('blocker_dashboard'))

    return render_template(
        'blocker.html',
        **blocker_dashboard_context(editing_blocker=blocker),
    )


@app.route('/blocker/<int:blocker_id>/toggle', methods=['POST'])
@login_required
def toggle_blocker(blocker_id):
    blocker = BlockedWebsite.query.filter_by(
        id=blocker_id,
        user_id=current_user.id,
    ).first_or_404()
    blocker.is_active = not blocker.is_active
    _db.session.commit()
    flash(
        f"{blocker.website_name} schedule {'resumed' if blocker.is_active else 'cancelled'}.",
        'success',
    )
    return redirect(url_for('blocker_dashboard'))


@app.route('/blocker/<int:blocker_id>/delete', methods=['POST'])
@login_required
def delete_blocker(blocker_id):
    blocker = BlockedWebsite.query.filter_by(
        id=blocker_id,
        user_id=current_user.id,
    ).first_or_404()
    _db.session.delete(blocker)
    _db.session.commit()
    flash('Website schedule deleted.', 'success')
    return redirect(url_for('blocker_dashboard'))


@app.route('/api/blocked-sites/<username>')
def blocked_sites_api(username):
    user = User.query.filter_by(username=username).first()
    if user is None:
        return jsonify(error='User not found.'), 404

    schedules = BlockedWebsite.query.filter_by(
        user_id=user.id,
        is_active=True,
    ).order_by(BlockedWebsite.start_time.asc()).all()
    now = datetime.now().time()
    return jsonify(
        username=user.username,
        server_now_seconds=now.hour * 3600 + now.minute * 60 + now.second,
        schedules=[
            {
                'website_name': blocker.website_name,
                'domain_url': blocker.domain_url,
                'start_time': blocker.start_time.strftime('%H:%M'),
                'end_time': blocker.end_time.strftime('%H:%M'),
            }
            for blocker in schedules
        ],
    )


@app.route('/post/new', methods=['GET', 'POST'])
@login_required
def create_post():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        content = request.form.get('content', '').strip()
        image_url = request.form.get('image_url', '').strip() or None
        if not title or category not in {'Tech', 'Lifestyle', 'Travel'} or not content:
            flash('Please provide a title, category, and post content.', 'danger')
        else:
            post = Post(title=title, category=category, content=content,
                        image_url=image_url, author=current_user)
            _db.session.add(post)
            _db.session.commit()
            flash('Post created!', 'success')
            return redirect(url_for('post_detail', post_id=post.id))
    return render_template(
        'create_post.html',
        post=None,
        active_blockers=get_active_blocker_details(current_user.id, datetime.now().time()),
    )


@app.route('/post/<int:post_id>')
def post_detail(post_id):
    post = _db.session.get(Post, post_id)
    if post is None:
        abort(404)
    return render_template('post_detail.html', post=post)


@app.route('/post/<int:post_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_post(post_id):
    post = _db.session.get(Post, post_id)
    if post is None:
        abort(404)
    if post.author != current_user:
        abort(403)
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        content = request.form.get('content', '').strip()
        image_url = request.form.get('image_url', '').strip() or None
        if not title or category not in {'Tech', 'Lifestyle', 'Travel'} or not content:
            flash('Please provide a title, category, and post content.', 'danger')
        else:
            post.title = title
            post.category = category
            post.content = content
            post.image_url = image_url
            _db.session.commit()
            flash('Post updated!', 'success')
            return redirect(url_for('post_detail', post_id=post.id))
    return render_template(
        'create_post.html',
        post=post,
        active_blockers=get_active_blocker_details(current_user.id, datetime.now().time()),
    )


@app.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
def delete_post(post_id):
    post = _db.session.get(Post, post_id)
    if post is None:
        abort(404)
    if post.author != current_user:
        abort(403)
    _db.session.delete(post)
    _db.session.commit()
    flash('Post deleted.', 'success')
    return redirect(url_for('index'))


@app.route('/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    post = _db.session.get(Post, post_id)
    if post is None:
        abort(404)
    content = request.form.get('content', '').strip()
    if not content:
        flash('A comment cannot be empty.', 'danger')
    else:
        _db.session.add(Comment(content=content, post=post, author=current_user))
        _db.session.commit()
        flash('Comment added!', 'success')
    return redirect(url_for('post_detail', post_id=post_id))


@app.errorhandler(403)
def forbidden(error):
    return render_template('base.html'), 403


@app.errorhandler(404)
def not_found(error):
    return render_template('base.html'), 404


if __name__ == '__main__':
    app.run(debug=True)
