#!/usr/bin/env python3
"""Apply a user's daily website schedule to the managed section of the hosts file.

Keep the Flask app running while this script is active.

Windows (open Terminal as Administrator):
    py schedule_blocker.py --username alice

Linux/macOS:
    sudo python3 schedule_blocker.py --username alice

Use --dry-run to check the API and current schedule without editing the hosts file.
Use --once to perform one schedule check and exit.
"""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.error import URLError
from urllib.parse import quote, urlsplit, urljoin
from urllib.request import Request, urlopen


BEGIN_MARKER = "# BEGIN STILLPOINT SCHEDULED BLOCKER"
END_MARKER = "# END STILLPOINT SCHEDULED BLOCKER"
DOMAIN_PATTERN = re.compile(
    r"(?=.{1,253}\Z)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\Z",
    re.IGNORECASE,
)


def default_hosts_file():
    if os.name == "nt":
        windows_root = os.environ.get("SystemRoot", r"C:\Windows")
        return Path(windows_root) / "System32" / "drivers" / "etc" / "hosts"
    return Path("/etc/hosts")


def parse_clock_time(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{2}:\d{2}", value):
        raise ValueError(f"Invalid schedule time: {value!r}")
    try:
        return datetime.strptime(value, "%H:%M").time()
    except ValueError as error:
        raise ValueError(f"Invalid schedule time: {value!r}") from error


def schedule_is_active(start_time, end_time, now):
    if start_time == end_time:
        raise ValueError("A schedule cannot have identical start and end times.")
    if start_time < end_time:
        return start_time <= now < end_time
    return now >= start_time or now < end_time


def fetch_schedules(api_url, username):
    endpoint = urljoin(
        api_url.rstrip("/") + "/",
        f"api/blocked-sites/{quote(username, safe='')}",
    )
    request = Request(endpoint, headers={"Accept": "application/json"})
    with urlopen(request, timeout=10) as response:
        data = json.loads(response.read().decode("utf-8"))

    if not isinstance(data, dict):
        raise ValueError("The API response must be a JSON object.")
    schedules = data.get("schedules")
    if not isinstance(schedules, list):
        raise ValueError("The API response does not contain a schedules list.")

    parsed = []
    for schedule in schedules:
        if not isinstance(schedule, dict):
            raise ValueError("The API returned an invalid schedule entry.")
        domain = schedule.get("domain_url")
        if not isinstance(domain, str) or not DOMAIN_PATTERN.fullmatch(domain):
            raise ValueError(f"The API returned an invalid domain: {domain!r}")
        start_time = parse_clock_time(schedule.get("start_time"))
        end_time = parse_clock_time(schedule.get("end_time"))
        if start_time == end_time:
            raise ValueError(f"The API returned an ambiguous schedule for {domain}.")
        parsed.append((domain.lower(), start_time, end_time))
    return parsed


def scheduled_domains(schedules, now):
    domains = set()
    for domain, start_time, end_time in schedules:
        if schedule_is_active(start_time, end_time, now):
            root_domain = domain[4:] if domain.startswith("www.") else domain
            domains.add(root_domain)
            domains.add(f"www.{root_domain}")
    return domains


def outside_managed_lines(lines):
    starts = [index for index, line in enumerate(lines) if line.strip() == BEGIN_MARKER]
    ends = [index for index, line in enumerate(lines) if line.strip() == END_MARKER]
    if not starts and not ends:
        return lines, None, None
    if len(starts) != 1 or len(ends) != 1 or starts[0] >= ends[0]:
        raise ValueError("Hosts file has missing, duplicated, or misplaced blocker markers.")
    return lines[:starts[0]] + lines[ends[0] + 1:], starts[0], ends[0]


def check_for_existing_mappings(lines, domains):
    for line in lines:
        mapping = line.split("#", 1)[0].split()
        if len(mapping) < 2:
            continue
        mapped_domains = {host.lower().rstrip(".") for host in mapping[1:]}
        conflict = mapped_domains.intersection(domains)
        if conflict:
            names = ", ".join(sorted(conflict))
            raise ValueError(
                f"Hosts file already contains a mapping for {names} outside the "
                "Stillpoint section. Resolve it manually before enabling this schedule."
            )


def update_hosts_file(hosts_file, domains):
    with hosts_file.open("r", encoding="utf-8", newline="") as hosts_stream:
        original = hosts_stream.read()
    newline = "\r\n" if "\r\n" in original else "\n"
    lines = original.splitlines()
    outside_lines, start, end = outside_managed_lines(lines)
    check_for_existing_mappings(outside_lines, domains)

    managed_lines = [BEGIN_MARKER]
    managed_lines.extend(
        f"127.0.0.1 {domain}"
        for domain in sorted(domains)
    )
    managed_lines.append(END_MARKER)

    if start is None:
        updated_lines = lines[:]
        if updated_lines and updated_lines[-1].strip():
            updated_lines.append("")
        updated_lines.extend(managed_lines)
    else:
        updated_lines = lines[:start] + managed_lines + lines[end + 1:]

    updated = newline.join(updated_lines)
    if original.endswith(("\n", "\r")):
        updated += newline
    if updated != original:
        with hosts_file.open("w", encoding="utf-8", newline="") as hosts_stream:
            hosts_stream.write(updated)
        return True
    return False


def parse_arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--username", required=True, help="Blog account whose schedules to apply")
    parser.add_argument(
        "--api-url",
        default="http://127.0.0.1:5000",
        help="Flask application base URL (default: http://127.0.0.1:5000)",
    )
    parser.add_argument(
        "--hosts-file",
        type=Path,
        default=default_hosts_file(),
        help="Hosts file path (defaults to the current operating system's hosts file)",
    )
    parser.add_argument("--interval", type=int, default=30, help="Poll interval in seconds")
    parser.add_argument("--dry-run", action="store_true", help="Check the schedule without editing hosts")
    parser.add_argument("--once", action="store_true", help="Check and apply one schedule update, then exit")
    args = parser.parse_args()

    parsed_url = urlsplit(args.api_url)
    if parsed_url.scheme not in {"http", "https"} or not parsed_url.netloc:
        parser.error("--api-url must be an absolute HTTP or HTTPS URL.")
    if args.interval < 1:
        parser.error("--interval must be at least one second.")
    return args


def synchronize(args):
    schedules = fetch_schedules(args.api_url, args.username)
    now = datetime.now().time()
    domains = scheduled_domains(schedules, now)
    if args.dry_run:
        print(f"Would block at {now.strftime('%H:%M')}: {', '.join(sorted(domains)) or 'none'}")
        return

    changed = update_hosts_file(args.hosts_file, domains)
    status = "updated" if changed else "already current"
    print(f"Hosts file {status}; {len(domains)} hostnames managed at {now.strftime('%H:%M')}.")


def main():
    args = parse_arguments()
    try:
        while True:
            try:
                synchronize(args)
            except (URLError, TimeoutError, json.JSONDecodeError, ValueError) as error:
                print(f"Schedule check failed; existing managed entries were kept: {error}", file=sys.stderr)
            except PermissionError as error:
                raise SystemExit(
                    f"Cannot write {args.hosts_file}. Run this script as Administrator or with sudo."
                ) from error

            if args.once or args.dry_run:
                return
            time.sleep(args.interval)
    except KeyboardInterrupt:
        if not args.dry_run:
            print("\nStopping and removing Stillpoint-managed host entries.")
            try:
                update_hosts_file(args.hosts_file, set())
            except (OSError, ValueError) as error:
                print(f"Could not clean the managed hosts section: {error}", file=sys.stderr)
        return


if __name__ == "__main__":
    main()
