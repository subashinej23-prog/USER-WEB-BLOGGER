"use strict";

(() => {
  const widget = document.querySelector("#blockedSitesWidget");
  if (!widget) {
    return;
  }

  const message = document.querySelector("#blockedSitesMessage");
  const list = document.querySelector("#blockedSitesList");
  const apiUrl = widget.dataset.apiUrl;

  function isInTimeWindow(start, end, nowMinutes) {
    const [startHour, startMinute] = start.split(":").map(Number);
    const [endHour, endMinute] = end.split(":").map(Number);
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    return startMinutes < endMinutes
      ? startMinutes <= nowMinutes && nowMinutes < endMinutes
      : nowMinutes >= startMinutes || nowMinutes < endMinutes;
  }

  function renderSchedules(schedules, serverTimeSeconds, receivedAt) {
    const elapsedSeconds = Math.floor((performance.now() - receivedAt) / 1000);
    const nowSeconds = (serverTimeSeconds + elapsedSeconds) % (24 * 60 * 60);
    const nowHours = Math.floor(nowSeconds / 3600);
    const nowMinutes = Math.floor((nowSeconds % 3600) / 60);
    const now = nowHours * 60 + nowMinutes;
    const active = schedules.filter((schedule) =>
      typeof schedule.domain_url === "string" &&
      /^\d{2}:\d{2}$/.test(schedule.start_time) &&
      /^\d{2}:\d{2}$/.test(schedule.end_time) &&
      isInTimeWindow(schedule.start_time, schedule.end_time, now)
    );

    list.replaceChildren();
    if (active.length === 0) {
      message.textContent = "No websites are blocked right now";
      return;
    }

    message.textContent = "Currently blocked";
    for (const schedule of active) {
      const item = document.createElement("li");
      const identity = document.createElement("span");
      const name = document.createElement("strong");
      const end = document.createElement("span");
      const currentTime = `${String(nowHours).padStart(2, "0")}:${String(nowMinutes).padStart(2, "0")}`;
      const overnight = schedule.start_time > schedule.end_time && currentTime >= schedule.start_time;

      name.textContent = schedule.website_name;
      identity.append(name, document.createTextNode(` · ${schedule.domain_url}`));
      end.textContent = `Ends ${schedule.end_time}${overnight ? " tomorrow" : ""}`;
      item.append(identity, end);
      list.append(item);
    }
  }

  async function refreshSchedules() {
    try {
      const response = await fetch(apiUrl, {
        cache: "no-store",
        headers: { Accept: "application/json" },
      });
      if (!response.ok) {
        throw new Error(`Schedule API returned HTTP ${response.status}.`);
      }
      const data = await response.json();
      if (!Array.isArray(data.schedules) || !Number.isInteger(data.server_now_seconds)) {
        throw new Error("Schedule API response is missing the schedule list or server clock.");
      }
      renderSchedules(data.schedules, data.server_now_seconds, performance.now());
      message.classList.remove("blocker-widget-error");
    } catch (error) {
      console.error("Could not refresh the website blocker widget.", error);
      message.textContent = "Live status could not be refreshed; showing the last saved status.";
      message.classList.add("blocker-widget-error");
    }
  }

  refreshSchedules();
  window.setInterval(refreshSchedules, 30_000);
})();
