"use strict";

(() => {
  const table = document.querySelector("#scheduleTable");
  if (!table) {
    return;
  }

  const serverNowSeconds = Number(table.dataset.serverNowSeconds);
  const serverSampledAt = performance.now();
  const rows = [...table.querySelectorAll(".schedule-row")];
  const secondsPerDay = 24 * 60 * 60;

  function secondsForTime(value) {
    const [hours, minutes] = value.split(":").map(Number);
    return hours * 3600 + minutes * 60;
  }

  function formatCountdown(totalSeconds) {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return [hours, minutes, seconds]
      .map((part) => String(part).padStart(2, "0"))
      .join(":");
  }

  function updateRow(row, nowSeconds) {
    const status = row.querySelector(".schedule-status");
    const countdown = row.querySelector(".countdown-cell");
    const enabled = row.dataset.enabled === "true";

    if (!enabled) {
      status.textContent = "Unblocked";
      status.classList.remove("status-blocked");
      status.classList.add("status-unblocked");
      countdown.textContent = "Cancelled";
      return;
    }

    const start = secondsForTime(row.dataset.startTime);
    const end = secondsForTime(row.dataset.endTime);
    const blocked = start < end
      ? nowSeconds >= start && nowSeconds < end
      : nowSeconds >= start || nowSeconds < end;

    status.textContent = blocked ? "Blocked" : "Unblocked";
    status.classList.toggle("status-blocked", blocked);
    status.classList.toggle("status-unblocked", !blocked);

    const target = blocked ? end : start;
    const remaining = (target - nowSeconds + secondsPerDay) % secondsPerDay;
    countdown.textContent = `${blocked ? "Unblocks" : "Blocks"} in ${formatCountdown(remaining)}`;
  }

  function updateDashboard() {
    const elapsedSeconds = Math.floor((performance.now() - serverSampledAt) / 1000);
    const nowSeconds = (serverNowSeconds + elapsedSeconds) % secondsPerDay;
    for (const row of rows) {
      updateRow(row, nowSeconds);
    }
  }

  updateDashboard();
  window.setInterval(updateDashboard, 1000);
})();
