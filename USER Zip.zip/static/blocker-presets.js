"use strict";

(() => {
  const preset = document.querySelector("#websitePreset");
  const nameInput = document.querySelector("#website_name");
  const domainInput = document.querySelector("#domain_url");
  if (!preset || !nameInput || !domainInput) {
    return;
  }

  const matchingPreset = [...preset.options].find(
    (option) => option.dataset.name === nameInput.value
  );
  preset.value = matchingPreset ? matchingPreset.value : "custom";

  preset.addEventListener("change", () => {
    const option = preset.selectedOptions[0];
    if (preset.value === "custom") {
      nameInput.value = "";
      domainInput.value = "";
      nameInput.focus();
      return;
    }

    nameInput.value = option.dataset.name || "";
    domainInput.value = option.dataset.domain || "";
    if (!domainInput.value) {
      domainInput.focus();
    }
  });
})();
